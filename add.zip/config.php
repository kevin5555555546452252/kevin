<?php
//这个是配置文件

//链接数据库
require_once 'conn.php';

//全站标题
$title = "我的留言板";